#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import javax.ws.rs.Path;
import rest.provider.Provider;

#parse("File Header.java")
@Path("${pathname}")
public class ${Entity_Name}Resource extends Provider {

    private final I${Entity_Name}Repository REPO = ${Entity_Name}Facade.getInstance(EMF);
}