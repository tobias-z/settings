#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import java.util.function.Consumer;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.ws.rs.WebApplicationException;

#parse("File Header.java")
public class ${NAME} #if (${Optional_Repository} && ${Optional_Repository} != "") implements ${Optional_Repository}#end {

    private static ${NAME} instance;
    private static EntityManagerFactory emf;
    
    private ${NAME}() {}
    
    public static ${NAME} getInstance(EntityManagerFactory _emf) {
        if (instance == null) {
            emf = _emf;
            instance = new ${NAME}();
        }
        return instance;
    }

}