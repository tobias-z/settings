#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end

import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Column;
import javax.persistence.Table;

@Entity
@Table(name = "${Table_name}")
@NamedQueries({
    @NamedQuery(name = "${NAME}.deleteAllRows", query = "DELETE from ${NAME}"),
    @NamedQuery(name = "${NAME}.getAll", query = "Select u from ${NAME} u")
})
public class ${NAME} implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;

    public ${NAME}() {
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }
}
